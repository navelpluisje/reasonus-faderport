local function main()
  local functionAction = 40341;
  reaper.Main_OnCommandEx(functionAction, 0, 0);
end

main()
