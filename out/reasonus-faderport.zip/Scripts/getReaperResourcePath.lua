local path = reaper.GetResourcePath()
reaper.ShowConsoleMsg("Path: " .. path)